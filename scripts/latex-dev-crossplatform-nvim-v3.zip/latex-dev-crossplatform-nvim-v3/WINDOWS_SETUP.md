# Windows + MiKTeX + Neovim LaTeX setup

이 패키지는 `younghoonJ/latex-dev`의 기존 Ubuntu Neovim 설정을 공통 `nvim/` 디렉터리로 분리한 버전입니다.

## 구성

- Ubuntu: Neovim + VimTeX + latexmk + Okular (기본), Zathura 선택 가능
- Windows: Neovim + VimTeX + MiKTeX/latexmk + SumatraPDF
- 공통: lazy.nvim, VimTeX v2.18, TexLab/Mason, blink.cmp, Telescope, nvim-tree, Oil, TokyoNight, which-key, bufferline, lualine
- Windows SumatraPDF: forward SyncTeX + inverse SyncTeX helper 포함

## Windows에서 가장 쉬운 설치

MiKTeX는 이미 설치했다고 가정합니다. 가장 간단하게는 ZIP을 푼 뒤 `install-windows.cmd`를 실행하면 됩니다.

PowerShell에서 직접 실행하려면:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\install-nvim-latex.ps1 -InstallDependencies
```

`-InstallDependencies`는 없을 때 `winget`으로 Git, Neovim, ripgrep, Strawberry Perl, SumatraPDF를 설치합니다. MiKTeX는 건드리지 않습니다.

이미 나머지도 설치되어 있으면:

```powershell
.\scripts\install-nvim-latex.ps1
```

기존 `%LOCALAPPDATA%\nvim`은 `nvim.backup.YYYYMMDD-HHMMSS`로 백업한 뒤 공통 설정을 복사합니다.

## MiKTeX 확인

새 PowerShell에서:

```powershell
pdflatex --version
latexmk -v
perl -v
```

`latexmk`가 없다면 MiKTeX Console의 Packages에서 `latexmk`를 설치하세요.

## 사용

LaTeX 파일을 열고:

- `,ll` : VimTeX continuous compile
- `,lv` : SumatraPDF 열기 / forward SyncTeX
- `,li` : VimTeX info
- `,le` : errors
- `,lc` : clean

`maplocalleader`는 기존 Ubuntu 설정과 동일하게 `,`입니다.

## SumatraPDF inverse search

설치 스크립트는 SumatraPDF inverse-search command를 자동 등록합니다. Windows Neovim 설정은 `\\.\pipe\nvim-latex`라는 고정 RPC pipe를 추가로 열며, SumatraPDF에서 PDF를 더블클릭하면 `scripts/sumatra-inverse-search.ps1`을 통해 해당 `.tex` 파일/줄로 돌아갑니다.

첫 Neovim 인스턴스가 이 고정 pipe를 소유합니다. 여러 Neovim을 동시에 띄운 경우 inverse search는 첫 인스턴스로 이동합니다.

## Ubuntu에 적용

이 폴더를 기존 `latex-dev` 저장소 루트로 복사한 뒤:

```bash
SKIP_NEOVIM=1 ./scripts/install-nvim-latex.sh
```

Neovim 자체도 다시 설치하려면 `SKIP_NEOVIM=1`을 빼면 됩니다.

Zathura를 원하면:

```bash
PDF_VIEWER=zathura SKIP_NEOVIM=1 ./scripts/install-nvim-latex.sh
```

## 기존 repo에 병합할 파일

```text
nvim/
scripts/install-nvim-latex.sh
scripts/install-nvim-latex.ps1
scripts/sumatra-inverse-search.ps1
WINDOWS_SETUP.md
```

기존 `scripts/install-nvim-latex.sh`가 heredoc으로 Lua 설정을 생성하던 부분을 없애고, 이제 `nvim/`을 복사하도록 변경한 것이 핵심입니다.

## 설치 확인 스크립트

```powershell
.\scripts\verify-windows.ps1
```

Neovim, Git, MiKTeX/latexmk, Perl, ripgrep, SumatraPDF 및 Neovim config 위치를 한 번에 확인합니다.


## v3 installer note

The installer now treats an already-installed winget package as success even when its executable is not on PATH. This specifically fixes SumatraPDF installations for which `winget install` reports that no upgrade is available and returns a non-zero exit code.
