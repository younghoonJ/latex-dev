vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1

vim.g.mapleader = " "
vim.g.maplocalleader = ","

-- On Windows, expose a stable RPC pipe for SumatraPDF inverse SyncTeX.
-- Neovim 0.12 also creates its own default server; this is an additional,
-- predictable address used only by the inverse-search helper.
if vim.fn.has("win32") == 1 then
  pcall(vim.fn.serverstart, [[\\.\pipe\nvim-latex]])
end

require("config.options")
require("config.keymaps")
require("config.lazy")
