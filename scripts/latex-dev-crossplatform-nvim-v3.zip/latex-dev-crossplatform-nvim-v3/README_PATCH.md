# latex-dev cross-platform Neovim patch

Target repository: https://github.com/younghoonJ/latex-dev

이 ZIP의 내용을 repository root에 복사하면 됩니다.

핵심 변경:

1. Neovim Lua 설정을 `scripts/install-nvim-latex.sh` heredoc에서 `nvim/`으로 분리
2. 동일한 `nvim/` 설정을 Ubuntu와 Windows에서 공유
3. Windows에서는 자동으로 SumatraPDF를 사용
4. Ubuntu에서는 기존 Okular 설정 유지 (`PDF_VIEWER=zathura` 선택 가능)
5. Windows PowerShell 설치 스크립트 추가
6. SumatraPDF inverse SyncTeX용 PowerShell helper + 고정 Neovim RPC pipe 추가

Windows 사용법은 `WINDOWS_SETUP.md`를 보세요.
