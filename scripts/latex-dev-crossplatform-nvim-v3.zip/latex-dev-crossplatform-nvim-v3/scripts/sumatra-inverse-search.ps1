param(
    [Parameter(Mandatory = $true)]
    [int]$Line,

    [Parameter(Mandatory = $true)]
    [string]$File
)

$ErrorActionPreference = "Stop"
$Server = '\\.\pipe\nvim-latex'

$nvim = Get-Command nvim -ErrorAction SilentlyContinue
if (-not $nvim) {
    exit 1
}

# Open/drop the source in the already-running Neovim instance.
# --remote consumes all following arguments as file names, so line movement
# is sent as a second RPC command.
& $nvim.Source --server $Server --remote $File | Out-Null
if ($LASTEXITCODE -ne 0) {
    # Fall back to a normal Neovim process if the stable pipe is unavailable.
    Start-Process -FilePath $nvim.Source -ArgumentList @("+$Line", "`"$File`"")
    exit 0
}

$keys = "<C-\><C-N>:call cursor($Line, 1)<CR>zz"
& $nvim.Source --server $Server --remote-send $keys | Out-Null
