[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

function Find-Nvim {
    $cmd = Get-Command nvim.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\nvim.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Neovim\bin\nvim.exe'),
        (Join-Path $env:ProgramFiles 'Neovim\bin\nvim.exe')
    )
    foreach ($p in $candidates) {
        if ($p -and (Test-Path $p)) { return $p }
    }

    $wingetRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages'
    if (Test-Path $wingetRoot) {
        $hit = Get-ChildItem -Path $wingetRoot -Filter nvim.exe -Recurse -ErrorAction SilentlyContinue |
            Select-Object -First 1
        if ($hit) { return $hit.FullName }
    }
    return $null
}

function Find-SumatraPDF {
    $cmd = Get-Command SumatraPDF.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'SumatraPDF\SumatraPDF.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\SumatraPDF\SumatraPDF.exe'),
        (Join-Path $env:ProgramFiles 'SumatraPDF\SumatraPDF.exe')
    )
    if (${env:ProgramFiles(x86)}) {
        $candidates += (Join-Path ${env:ProgramFiles(x86)} 'SumatraPDF\SumatraPDF.exe')
    }
    foreach ($p in $candidates) {
        if ($p -and (Test-Path $p)) { return $p }
    }

    $keys = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\SumatraPDF.exe',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\SumatraPDF.exe',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\SumatraPDF.exe'
    )
    foreach ($key in $keys) {
        try {
            $item = Get-Item $key -ErrorAction Stop
            $value = $item.GetValue('')
            if ($value -and (Test-Path $value)) { return $value }
        } catch {}
    }
    return $null
}

$configDir = Join-Path $env:LOCALAPPDATA 'nvim'
$init = Join-Path $configDir 'init.lua'
$toolsDir = Join-Path $configDir 'tools'
$helper = Join-Path $toolsDir 'sumatra-inverse-search.ps1'

if (-not (Test-Path $init)) {
    throw "Neovim config not found: $init"
}

$nvim = Find-Nvim
if (-not $nvim) { throw 'nvim.exe could not be located.' }
$sumatra = Find-SumatraPDF
if (-not $sumatra) { throw 'SumatraPDF.exe could not be located.' }

New-Item -ItemType Directory -Force -Path $toolsDir | Out-Null

# Replace the older serverstart block from v3 with the canonical Windows named-pipe form.
$text = Get-Content -Raw -Path $init
$old = @'
if vim.fn.has("win32") == 1 then
  pcall(vim.fn.serverstart, [[\\.\pipe\nvim-latex]])
end
'@
$new = @'
if vim.fn.has("win32") == 1 then
  -- Stable RPC endpoint used by SumatraPDF inverse SyncTeX.
  -- Neovim documents //./pipe/... as the Windows named-pipe form.
  local inverse_pipe = "//./pipe/nvim-latex"
  local ok, err = pcall(vim.fn.serverstart, inverse_pipe)
  if not ok then
    vim.schedule(function()
      vim.notify("Inverse SyncTeX RPC server: " .. tostring(err), vim.log.levels.WARN)
    end)
  end
end
'@

if ($text.Contains($old)) {
    $text = $text.Replace($old, $new)
} elseif ($text -notmatch 'nvim-latex') {
    $text = $new + "`r`n" + $text
} else {
    # Handle path spelling differences without touching the rest of the config.
    $text = $text -replace '\[\[\\\\\.\\pipe\\nvim-latex\]\]', '"//./pipe/nvim-latex"'
}
Set-Content -Path $init -Value $text -Encoding utf8

# The helper uses the exact nvim.exe path, so Sumatra does not depend on Explorer's stale PATH.
$escapedNvim = $nvim.Replace("'", "''")
$helperText = @"
param(
    [Parameter(Mandatory = `$true)][int]`$Line,
    [Parameter(Mandatory = `$true)][string]`$File
)

`$ErrorActionPreference = 'Stop'
`$Server = '//./pipe/nvim-latex'
`$Nvim = '$escapedNvim'
`$Log = Join-Path `$env:TEMP 'nvim-sumatra-inverse.log'

try {
    if (-not (Test-Path `$Nvim)) { throw "nvim.exe not found: `$Nvim" }

    & `$Nvim --server `$Server --remote `$File 2>> `$Log | Out-Null
    if (`$LASTEXITCODE -ne 0) {
        throw "Could not connect to Neovim server `$Server (exit `$LASTEXITCODE)."
    }

    `$keys = "<C-\><C-N>:call cursor(`$Line, 1)<CR>zz"
    & `$Nvim --server `$Server --remote-send `$keys 2>> `$Log | Out-Null
    if (`$LASTEXITCODE -ne 0) {
        throw "remote-send failed (exit `$LASTEXITCODE)."
    }
}
catch {
    Add-Content -Path `$Log -Value ((Get-Date -Format s) + ' ' + `$_.Exception.Message)
    exit 1
}
"@
Set-Content -Path $helper -Value $helperText -Encoding ascii

# Persist the inverse-search command in Sumatra. Hide the PowerShell console window.
$inverseCmd = 'powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $helper + '" -Line %l -File "%f"'
Start-Process -FilePath $sumatra -ArgumentList @('-reuse-instance', '-inverse-search', $inverseCmd) | Out-Null

Write-Host ''
Write-Host 'Inverse SyncTeX fix installed.' -ForegroundColor Green
Write-Host "Neovim : $nvim"
Write-Host "Sumatra: $sumatra"
Write-Host "Helper : $helper"
Write-Host ''
Write-Host 'Close all Neovim and SumatraPDF windows, then reopen Neovim and test again.'
Write-Host 'Inside Neovim, run:  :echo serverlist()'
Write-Host 'The list should contain a nvim-latex named pipe.'
Write-Host 'If inverse search still fails, inspect: %TEMP%\nvim-sumatra-inverse.log'
