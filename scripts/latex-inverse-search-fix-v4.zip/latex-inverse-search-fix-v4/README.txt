Windows Neovim + SumatraPDF inverse SyncTeX fix v4

1. Extract this ZIP completely.
2. Double-click fix-inverse-search.cmd.
3. Close ALL Neovim and SumatraPDF windows.
4. Open a new terminal, run nvim main.tex, compile with ,ll, and open PDF with ,lv.
5. In Neovim run :echo serverlist(). It should include nvim-latex.
6. Double-click text in SumatraPDF.

This patch fixes three issues in v3:
- Uses Neovim's canonical Windows named-pipe form: //./pipe/nvim-latex
- Uses the full path to nvim.exe (does not depend on Sumatra/Explorer PATH)
- Runs the inverse-search PowerShell helper hidden and no longer launches a fallback Neovim window

If it still fails, open:
  %TEMP%\nvim-sumatra-inverse.log
