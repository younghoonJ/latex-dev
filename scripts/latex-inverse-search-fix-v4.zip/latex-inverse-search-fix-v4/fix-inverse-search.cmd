@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0fix-inverse-search.ps1"
if errorlevel 1 (
  echo.
  echo Fix failed with exit code %errorlevel%.
  pause
  exit /b %errorlevel%
)
echo.
pause
